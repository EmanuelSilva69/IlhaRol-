# IlhaRolê

Protótipo de plataforma web de agenda cultural e eventos em São Luís (MA). O projeto está dividido em três frentes de trabalho:

- `devops/` — Docker, PostgreSQL, ambiente e scripts de banco;
- `backend/` — esqueleto da API em FastAPI;
- `frontend/` — wireframe em React/Vite com o componente de mapa.

O restante do produto (autenticação, CRUD de eventos, feed, favoritos, avaliações e notificações) será construído pelas equipes responsáveis sobre esta base.

## Estado atual

Este repositório é um **protótipo**, não um site final:

- o front-end é um protótipo navegável em preto e branco, com seis telas (feed/mapa, detalhes, login, agenda, organizador e perfil);
- o back-end já expõe autenticação JWT, perfil, eventos, favoritos, avaliações, notificações, denúncias e recuperação de senha;
- o front-end consome a API quando ela está disponível e mantém um fallback mockado para o protótipo;
- o mapa Leaflet, os filtros, a agenda e a central de perfil funcionam sobre esse estado.

## API e progresso da Sprint 1

A API FastAPI usa PostgreSQL, Argon2 e JWT. O feed, o login/cadastro e o perfil
já conversam com o banco; favoritos, avaliações e denúncias usam as rotas
autenticadas.

| RF | Situação |
| --- | --- |
| RF01a — cadastro, login e JWT | concluído |
| RF01b — perfil, bairro, bio e interesses | concluído |
| RF02 — publicar evento | concluído na API e na área do organizador |
| RF03 — feed, busca e filtros | concluído no front-end e na API |
| RF04 — detalhes com mapa | concluído |
| RF05 — favoritos | concluído |
| RF06 — avaliações pós-evento | concluído |
| RF07 — gerenciar eventos próprios | parcial: cancelamento via API; edição de campos ainda simulada |
| RF08 — alertas de novos eventos | concluído no back-end (categoria/bairro/Preferências) |
| RF09 — recuperação de acesso | parcial: API e solicitação de link; falta tela de redefinição |
| RF10 — agenda pessoal | concluído |
| RF11 — avisos de alteração/cancelamento | concluído no back-end |
| RF12 — preferências de alerta | concluído |
| RF13 — compartilhar evento | concluído (clipboard) |
| RF14 — denunciar conteúdo | concluído para evento e avaliação |

A meta de 25% dos RFs essenciais da Sprint 1 (RF01a + RF03) foi superada;
os 7 RFs essenciais já têm pelo menos o fluxo principal implementado. Ainda
faltam integrações de produção: envio real de e-mail, upload de mídia,
moderação administrativa e testes E2E.

## Estrutura

```text
.
├── devops/             # Docker, banco, ambiente e scripts
├── backend/            # API FastAPI
├── frontend/           # Wireframe React/Vite
├── documentos/         # Documentos iniciais do projeto
├── openspec/           # Especificações e mudanças do projeto
└── README.md
```

## Stack

- **Banco:** PostgreSQL 16
- **Back-end:** Python 3.12 + FastAPI + SQLAlchemy assíncrono + asyncpg
- **Front-end:** React 19 + Vite + Tailwind CSS 4 + Leaflet
- **Infra local:** Docker e Docker Compose

## Pré-requisitos

- Docker Desktop com Docker Compose v2
- Node.js 22+ (apenas para executar o front-end sem Docker)
- Portas `8000` e `5173` livres no host

## Configuração inicial

```powershell
Copy-Item devops\.env.example devops\.env
```

```bash
# Linux/macOS
cp devops/.env.example devops/.env
```

O arquivo `devops/.env` é ignorado pelo Git. Nunca versione credenciais reais.

### Variáveis de ambiente

| Variável | Padrão no exemplo | Descrição |
| --- | --- | --- |
| `POSTGRES_DB` | `ilharole` | Nome do banco criado pelo PostgreSQL |
| `POSTGRES_USER` | `ilharole` | Usuário do banco |
| `POSTGRES_PASSWORD` | `change-me-in-local-env` | Senha local do banco |
| `POSTGRES_HOST` | `db` | Host do banco na rede interna do Compose |
| `POSTGRES_PORT` | `5432` | Porta interna do PostgreSQL |
| `API_PORT` | `8000` | Porta da API no host |
| `WEB_PORT` | `5173` | Porta da interface no host |
| `CORS_ORIGINS` | `http://localhost:5173` | Origens autorizadas a chamar a API |
| `CARTO_API_KEY` | vazio | Chave dos Basemaps CARTO; fica só no `devops/.env` local |

A chave `CARTO_API_KEY` é repassada ao front-end como `VITE_CARTO_API_KEY`. Variáveis `VITE_*` são incorporadas ao bundle do navegador, então a chave é pública em execução; restrinja os domínios permitidos no painel da CARTO.

## Subir a stack

A partir da raiz do repositório:

```bash
docker compose -f devops/docker-compose.yml up --build -d
docker compose -f devops/docker-compose.yml ps
```

Serviços esperados:

| Serviço | Endereço | Verificação |
| --- | --- | --- |
| `web` | http://localhost:5173 | Wireframe React/Vite |
| `api` | http://localhost:8000 | API FastAPI |
| `api` (docs) | http://localhost:8000/docs | Documentação OpenAPI |
| `db` | `localhost:5432` (loopback) | PostgreSQL 16; porta configurável em `POSTGRES_EXPOSE_PORT` |

Para acompanhar os logs:

```bash
docker compose -f devops/docker-compose.yml logs -f api
```

Para parar o ambiente:

```bash
docker compose -f devops/docker-compose.yml down
```

Os dados do PostgreSQL permanecem no volume `ilharole_pgdata`. Para descartar os dados de forma explícita:

```bash
docker compose -f devops/docker-compose.yml down -v
```

## Back-end

O back-end é um esqueleto declaradamente de protótipo. Rotas disponíveis:

- `GET /` — identifica a API como protótipo;
- `GET /health` — verifica a conexão com o banco;
- `GET /docs` — Swagger UI.

Detalhes em [`backend/README.md`](backend/README.md).

```bash
docker compose -f devops/docker-compose.yml up -d db api
curl http://localhost:8000/health
```

### Testes do back-end

```bash
docker compose -f devops/docker-compose.yml run --rm api pytest -q
```

## Front-end

O front-end é um wireframe de baixa fidelidade. O mapa é o único componente funcional e está documentado em [`frontend/README.md`](frontend/README.md).

```bash
docker compose -f devops/docker-compose.yml up -d web
```

Acesse http://localhost:5173. O diretório `frontend/` é montado como volume e o Vite observa alterações com polling.

### Executar sem Docker

```bash
cd frontend
npm install
npm run dev
```

### Testes e build do front-end

```bash
cd frontend
npm test
npm run build
```

Ou, com Docker:

```bash
docker compose -f devops/docker-compose.yml run --rm web npm test
```

## Banco de dados

O serviço `db` usa o volume `ilharole_pgdata`, uma configuração própria em
`devops/db/postgresql.conf` e executa os scripts de `devops/db/init/` apenas na
primeira criação do volume. O schema evolui por migrações versionadas em
`devops/db/migrations/`, com checksum e histórico em `app.schema_migrations`.

```powershell
.\devops\scripts\db-shell.ps1
.\devops\scripts\db-migrate.ps1
.\devops\scripts\db-roles.ps1
.\devops\scripts\db-seed.ps1
.\devops\scripts\db-check.ps1
.\devops\scripts\db-test.ps1
.\devops\scripts\db-stats.ps1
.\devops\scripts\db-backup.ps1
.\devops\scripts\db-restore.ps1
```

```bash
./devops/scripts/db-shell.sh
./devops/scripts/db-migrate.sh
./devops/scripts/db-roles.sh
./devops/scripts/db-seed.sh
./devops/scripts/db-check.sh
./devops/scripts/db-test.sh
./devops/scripts/db-stats.sh
./devops/scripts/db-backup.sh
./devops/scripts/db-restore.sh
```

Além do schema de domínio, há busca full-text em português, similaridade por
trigramas, busca por proximidade geográfica, auditoria, views de analytics e
perfis opcionais de pgAdmin, PgBouncer, backup automático e métricas. Consulte
[`devops/db/README.md`](devops/db/README.md) e
[`devops/db/FEATURES.md`](devops/db/FEATURES.md).

## DevOps

Toda a infraestrutura está em [`devops/`](devops/README.md): `docker-compose.yml`, Dockerfiles, `.env.example`, inicialização do banco e scripts.

## Verificação

Verificação executada em 12/11/2026:

- `docker compose -f devops/docker-compose.yml up --build -d`: `db`, `api` e `web` ficaram `healthy`.
- `GET http://localhost:8000/health`: `200` com `{"status":"ok","database":"connected"}`.
- `GET http://localhost:8000/`: resposta identifica a API como protótipo.
- `http://localhost:5173`: wireframe com “Header aqui”, “Feed de eventos”, “Mapa de eventos” e “Footer aqui”.
- Mapa: temas claro, escuro e temático funcionando; marcadores de exemplo para as 10 categorias (Bumba, Música/Reggae, Teatro, Gastronomia, Museus, Tambor de Crioula, Samba/Pagode, Orla/Praia, Feirinhas/Artesanato e Cinema/Audiovisual).
- `prefers-reduced-motion: reduce`: animações dos marcadores desligadas.
- Testes: 10 no back-end e 29 no front-end; build de produção gerado.
- Scripts `db-shell` e `db-backup` testados; script de inicialização executado em volume novo.
- Banco: init, 6 migrações, seed, verificação estrutural, smoke tests, reset, backup/restore e perfis pgAdmin/PgBouncer/exporter/backup testados em volume novo.
- Perfil: central do usuário com dados, agenda, avaliações, eventos, notificações, denúncias e segurança; perfil persistido no `localStorage` do protótipo.

## Publicação

Repositório: https://github.com/EmanuelSilva69/IlhaRol-

## Comentários
- Emanuel -> deixei o openspec ai pois ele é legal de ver os planos e oq falta fazer, se quiserem usar ele, façam um novo planejamento e vão botando lá, fica mais fácil de rastrear oq a ia fez e tal
